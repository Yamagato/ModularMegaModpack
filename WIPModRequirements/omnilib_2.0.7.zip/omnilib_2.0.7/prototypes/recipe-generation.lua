RecGen = {}
RecGen.__index = RecGen

ItemGen = {}
ItemGen.__index = ItemGen

RecChain = {}
RecChain.__index = RecChain

BotGen = {}
BotGen.__index = BotGen

TechGen = {}
TechGen.__index = TechGen


BuildGen = {}
BuildGen.__index = BuildGen


OmniGen = {}
OmniGen.__index = OmniGen

setmetatable(RecGen, {
  __index = ItemGen, -- this is what makes the inheritance work
  __call = function (cls, ...)
    local self = setmetatable({}, cls)
    self:create(...)
    return self
  end,
})

setmetatable(RecChain, {
  __index = RecGen, -- this is what makes the inheritance work
  __call = function (cls, ...)
    local self = setmetatable({}, cls)
    self:create(...)
    return self
  end,
})

setmetatable(BuildGen, {
  __index = RecGen, -- this is what makes the inheritance work
  __call = function (cls, ...)
    local self = setmetatable({}, cls)
    self:create(...)
    return self
  end,
})

setmetatable(BotGen, {
  __index = BuildGen, -- this is what makes the inheritance work
  __call = function (cls, ...)
    local self = setmetatable({}, cls)
    self:create(...)
    return self
  end,
})

local parents  = {BuildGen,RecChain}
local rawset   = rawset
local cache_mt = {}
function cache_mt:__index(key)
  for i = 1, #parents do
    local parent = parents[i]

    local value = parent[key]
    if value ~= nil then
      rawset(self, key, value)
      return value
    end
  end
end
function createClass (...)
	local c = {}        -- new class
    
      -- class will search for each method in the list of its
      -- parents (`arg' is the list of parents)
	setmetatable(c, {__index = function (t, k)
		return search(k, arg)
	end})
    
      -- prepare `c' to be the metatable of its instances
	c.__index = c
    
      -- define a new constructor for this new class
	function c:new (o)
		o = o or {}
		setmetatable(o, c)
		return o
	end
    
      -- return new class
	return c
end
local function search (k, plist)
	for i=1, table.getn(plist) do
		local v = plist[i][k]     -- try `i'-th superclass
		if v then return v end
	end
end
function cache_mt:__call(cls, ...)
    local self = setmetatable({}, cls)
    self:create(...)
    return self
end

local cache = setmetatable({}, cache_mt)


BuildChain = createClass(RecChain,BuildGen)
--BuildChain.__index = BuildChain

setmetatable(BuildChain, {
  __index = cache,
  __call = function (cls, ...)
    local self = setmetatable({}, cls)
    self:create(...)
    return self
	end
})


local ord={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}


function OmniGen:create()
	return setmetatable({
		type = "chain",
		shift = {},
		input = {
			items = {
			},
			sum=function(levels,grade) return 12 end
		},
		output = {
			yield={
				items = {
				},
				quant = function(levels,grade) return linear_gen(6,12,levels,grade) end
			},
			waste = {
				items = {
					"omnic-waste",
					"stone-crushed"
				},
				quant = function(levels,grade) return 12 - linear_gen(6,12,levels,grade) end
			}
		}
	},OmniGen)
end
function OmniGen:linearOutput(total,start,finish)
	self.output.yield.quant = function(levels,grade) return linear_gen(start,finish or total,levels,grade) end
	self.output.waste.quant = function(levels,grade) return total-linear_gen(start,finish or total,levels,grade) end
	return self
end
function OmniGen:linearPercentOutput(total,start,finish)
	self.output.yield.quant = function(levels,grade) return linear_gen(start*total,(finish or 1)*total,levels,grade) end
	self.output.waste.quant = function(levels,grade) return total-linear_gen(start*total,(finish or 1)*total,levels,grade) end
	return self
end
function OmniGen:wasteQuant(operation)
	self.output.waste.quant=operation
	return self
end
function OmniGen:yieldQuant(operation)
	self.output.yield.quant=operation
	return self
end
function OmniGen:setInputAmount(array)
	if type(array)=="function"  then
		self.input.sum = array
	elseif type(array)=="number" then
		self.input.sum = function(levels,grade) return array end
	end
	return self
end
function OmniGen:setIngredients(array,...)
	local arg = {...}
	if #arg > 0 then
		if array.name then
			array = {array}
		elseif type(array[1]) == "string" then
			array={{name=array[1], amount=array[2] or 0, type="item"}}
		end
		for i,v in pairs(arg) do
			local c = v
			if type(v[1])=="string" then c = {name=v[1],amount=v[2],type="item"} end
			array = omni.lib.union(array,{c})
		end
	end
	if type(array)=="table" then
		if array.name then
			self.input.items = {array}
		else
			self.input.items = array
		end
	else
		self.input.items = {{name=array}}
	end
	return self
end
function OmniGen:addIngredients(item)
	table.insert(self.input.items,item)
end
function OmniGen:setYield(array)
	if type(array)=="table" then
		self.output.yield.items = {array}
	else
		self.output.yield.items = {{name = array}}
	end
	return self
end
function OmniGen:addYield(item)
	local t = item
	if type(item)=="string" then t={name=item} end
	table.insert(self.output.yield.items,t)
end
function OmniGen:setWaste(array,...)
	local arg = {...}
	if #arg > 0 then
		if array.name then
			array = {array}
		elseif type(array[1]) == "string" then
			array={name=array[1]}
		elseif type(array)=="string" then
			array={name=array}
		end
		for i,v in pairs(arg) do
			local c = v
			if type(v[1])=="string" then c = {name=v[1],amount=v[2],type="item"} end
			array = omni.lib.union(array,{c})
		end
	end
	if type(array)=="table" then
		self.output.waste.items = {array}
	elseif type(array)=="string" then
		self.output.waste.items = {{name = array}}
	else 
		self.output.waste.items = nil
	end
	return self
end
function OmniGen:addWaste(item)
	table.insert(self.output.waste.items,item)
end
function OmniGen:ingredients()
	if self.type=="chain" then
		return self:chainIngredients()
	elseif self.type=="building" then
		return self:buildingCost()
	end
end
function OmniGen:results()
	if self.type=="chain" then
		return self:wasteYieldResults()
	elseif false then
		return self:buildingCost()
	end
end



result_round = function(array)
	if array.amount_min then array.amount = (array.amount_max+array.amount_max) end
	if math.floor(array.amount)~=array.amount then
		local nm = math.floor(array.amount)+1
		return {type=array.type,name=array.name,amount = nm,probability = array.amount/nm}
	else
		return array
	end
end

function OmniGen:chainIngredients()
	local f = function(levels,grade,dif)
		
		local usable = self.input.items
		local sum = clone_function(self.input.sum)(levels,grade)
		local total = 0
		
		local ingredients = {}
		for j,ing in pairs(usable) do
			local t = "item"
			if data.raw.fluid[ing.name] or ing.type == "fluid" then t = "fluid" end
			local amount = 0
			if ing.amount then
				amount = ing.amount
			else
				local ingname = ing.name or ing[1] or ing or ""
				math.randomseed(#usable*string.len(ingname)*j)
				if j ~= #usable then
					local expected = (sum-total)/(#usable-j)
					amount = math.random(omni.lib.round(expected*4/5),omni.lib.round(expected*6/5))
				else
					amount = sum-total
				end
			end
			total = total+amount
			ingredients[#ingredients+1]={type=t,name = ing.name,amount = amount}
		end
		return ingredients
	end
	return clone_function(f)
end

function OmniGen:wasteYieldResults()
	local f = function(levels,grade,dif)
		local max_yield = clone_function(self.output.yield.quant)(levels,grade)
		local yieldItems = table.deepcopy(self.output.yield.items)
		local wasteItems = table.deepcopy(self.output.waste.items)
		local yield_count = 0
		local total = 0
		local results = {}
		for j,yield in pairs(yieldItems) do
			local amount = 0
			yield_count = yield_count+1
			local t = "item"
			if data.raw.fluid[yield.name] then t = "fluid" end
			if not yield.portion then
				if j < #yieldItems then
					math.randomseed(#yieldItems*string.len(yield)+j)
					local expected = (max_yield-total)/(#yieldItems-j+1)
					amount = (0.1*math.random()+0.95)*expected
				else
					amount = max_yield-total
				end
			else
				amount = max_yield*portion
			end
			total = total+amount
			if amount > 0 then results[#results+1]=result_round({type=t,name = yield.name,amount = amount}) end
		end
		total = 0
		if wasteItems then
			local max_waste = clone_function(self.output.waste.quant)(levels,grade)
			for j,waste in pairs(wasteItems) do
				local amount = 0
				local t = "item"
				if data.raw.fluid[waste.name] then t = "fluid" end
				if j < #wasteItems then
					math.randomseed(#wasteItems*string.len(waste)+j)
					local expected = (max_waste-total)/(#wasteItems-j+1)
					amount = (0.1*math.random()+0.95)*expected
				else
					amount = max_waste-total
				end
				total = total+amount
				if amount > 0 then results[#results+1]=result_round({type=t,name = waste.name,amount = amount}) end
			end
		end
		return table.deepcopy(results)
	end
	return clone_function(f)
end

function prototype_icon(proto)
	local item = omni.lib.find_prototype(proto)
	local icons = {}
	if item ~= nil then
		if item.icon then
			icons = {{icon = item.icon}}
		else
			icons = item.icons
		end
	end
	if #icons == 0 or icons == {} then icons = nil end
	return icons
end

function linear_gen(start, final, levels, grade)
	return start + (final-start)*(grade-1)/(levels-1)
end
function standard_linear(levels,grade)
	return linear_gen(6,12,levels,grade)
end

function ItemGen:create(mod,name)
	local m = "__omnimatter_"..mod.."__"
	if string.find(mod, "omnimatter_crystal") or string.find(mod, "omnimatter_wood") then m = "__"..mod.."__"
	elseif not string.find(mod,"omnimatter") then m = "__"..mod.."__" end
	if mod == nil or mod == "omnimatter" then m = "__omnimatter__" end
	return setmetatable({
		mod = mod,
		name=name,
		loc_name=function(levels,grade) return nil end,
		loc_desc =  function(levels,grade) return nil end,
		icons = function(levels,grade) return {{icon = m.."/graphics/icons/"..name..".png"}} end,
		flags = {"goes-to-main-inventory"},
		order=function(levels,grade) return "a" end,
		stack_size = 100,
		subgroup = function(levels,grade) return "raw-resource" end,
		fuel_value = nil,
		fuel_category = nil,
		place_result = function(levels,grade) return nil end,
		rtn = {},
		type="item",
	},ItemGen)
end

function ItemGen:setIcons(icons,mod)
	local proto = nil
	if type(icons)=="string" then proto = omni.lib.find_prototype(icons) end
	if type(icons)~= "function" and mod and (type(icons)~= "string" or not string.match(icons, "%_%_(.-)%_%_")) then
		if type(icons)=="table" then
			local ic = {}
			for _, c in pairs(icons) do
				if type(icons)=="table" then
					ic[#ic+1]={icon = "__"..(mod or self.mod).."__/graphics/icons/"..c.name..".png",
						scale=c.scale,
						shift=c.shift}
				else
					ic[#ic+1]={icon = "__"..(mod or self.mod).."__/graphics/icons/"..c..".png"}
				end
			end
			self.icons = function(levels,grade) return ic end
		else
			self.icons = function(levels,grade) return {{icon = "__"..(mod or self.mod).."__/graphics/icons/"..icons..".png"}} end
		end
	elseif type(icons)~= "function" then
		if type(icons)=="string" and string.match(icons, "%_%_(.-)%_%_") then
			self.icons = function(levels,grade) return {{icon = icons}} end
		elseif type(icons) == "string" and not proto then
			self.icons = function(levels,grade) return {{icon = "__"..(mod or self.mod).."__/graphics/icons/"..icons..".png"}} end
		elseif proto then
			if proto.icons then
				self.icons=function(levels,grade) return proto.icons end
			else
				self.icons=function(levels,grade) return {{icon=proto.icon}} end
			end
		else
			self.icons = function(levels,grade) return icons end
		end
	else
		self.icons = icons
	end
	self.set_icon = true
	return self
end
function ItemGen:addIcon(icon)
	local a = nil
	if type(icon) == "table" and icon.icon then
		local f = string.match(icon.icon, "%_%_(.-)%_%_")
		if f then
			a = function(levels,grade) return {icon} end
		else
			local proto = omni.lib.find_prototype(icon.icon)
			if proto.icon then
				a = function(levels,grade) return {{icon=proto.icon,scale=icon.scale,shift=icon.shift}} end
			else
				local ic = {}
				for _, c in pairs(proto.icons) do
					ic[#ic+1] = {icon=c.icon,
						scale = (c.scale or 1)*(icon.scale or 1),
						shift = {(c.shift[1] or 0)+(icon.shift[1] or 0),(c.shift[2] or 0)+(icon.shift[2] or 0)}}
				end
				a = function(levels,grade) return ic end
			end
		end
	elseif type(icon)=="table" then
		a = function(levels,grade) return {{icon=icon[1]}} end
	else
		a = function(levels,grade) return {{icon=icon}} end
	end
	local f = clone_function(self.icons)
	self.icons = function(levels,grade) return table.union(f(levels,grade),a(levels,grade)) end
	self.set_icon = true
	return self
end
function ItemGen:addIconLevel(lvl)
	self:addIcon({icon = "__omnilib__/graphics/lvl"..lvl..".png"})
	return self
end
function ItemGen:setName(lvl)
	self.name = lvl
	return self
end
function ItemGen:addBurnerIcon()
	self:addIcon({icon = "__omnilib__/graphics/burner.png",
		scale = 0.4375,
		shift = {-10, 10}})
	return self
end
function ItemGen:addElectricIcon()
	self:addIcon({icon = "__omnilib__/graphics/electric.png",
		scale = 0.4375,
		shift = {-10, 10}})
	return self
end
function ItemGen:addSmallIcon(icon,nr)
	local quad = {{10, -10},{-10, -10},{-10, 10},{10, 10}}
	local icons = prototype_icon(icon)
	if icons then
		for _,ic in pairs(icons) do
			self:addIcon({icon = ic.icon,
				scale = 0.4375*(ic.scale or 1),
				shift = quad[nr or 1]})
		end
	else
		self:addIcon({icon = icon,
			scale = 0.4375,
			shift = quad[nr or 1]})
	end
	return self
end
function ItemGen:addBlankIcon()
	self:addIcon({icon = "__omnilib__/graphics/blank.png"})
	return self
end
function ItemGen:nullIcon()
	self:setIcons({icon = "__omnilib__/graphics/blank.png"})
	return self
end

function ItemGen:setSubgroup(subgroup)
	if type(subgroup)~= "function" then
		self.subgroup = function(levels,grade) return subgroup end
	else
		self.subgroup = subgroup
	end
	return self
end
function ItemGen:setStacksize(size)
	self.stack_size = size
	return self
end
function ItemGen:setFuelValue(fv)
	if type(fv)=="number" then
		self.fuel_value = fv.."MJ"
	elseif fv and string.find(fv,"J") then
		self.fuel_value=fv
	else
		self.fuel_value = fv
	end
	if self.fuel_value and not self.fuel_category then self:setFuelCategory() end
	return self
end
function ItemGen:setFuelCategory(fv)
	self.fuel_category = fv or "chemical"
	return self
end
function ItemGen:fluid()
	self.default_temperature = 25
    self.heat_capacity = "0.7KJ"
    self.base_color = {r = 1, g = 0, b = 1}
    self.flow_color = {r = 1, g = 0, b = 1}
    self.max_temperature = 100
	self.pressure_to_speed_ratio = 0.4
    self.flow_to_energy_ratio = 0.59
	self.type="fluid"
	return self
end
function ItemGen:setMaxTemp(tmp)
	if self.type=="fluid" then
		self.max_temperature=tmp
	end
	return self
end
function ItemGen:setCapacity(c)
	if self.type=="fluid" then
		if type(c)=="number" then
			self.heat_capacity=c.."KJ"
		else
			self.heat_capacity=c
		end
	end
	return self
end
function ItemGen:setMainInventory()
	self.flags = {"goes-to-main-inventory"}
	return self
end
function ItemGen:setQuickbar()
	self.flags = {"goes-to-quickbar"}
	return self
end
function ItemGen:setFlags(flags)
	if type(flags)=="table" then
		self.flags = flags
	else
		self.flags = {flags}
	end
	return self
end
function ItemGen:setBaseColour(r,g,b)
	if self.type=="fluid" then
		if g and b then
			self.base_color={r = r, g = g, b = b}
		elseif type(r)=="table" then
			self.base_color=r
		end
	end
	return self
end
function ItemGen:setFlowColour(r,g,b)
	if self.type=="fluid" then
		if g and b then
			self.flow_color={r = r, g = g, b = b}
		elseif type(r)=="table" then
			self.flow_color=r
		end
	end
	return self
end
function ItemGen:setBothColour(r,g,b)
	if self.type=="fluid" then
		if g and b then
			self:setBaseColour({r = r, g = g, b = b})
			self:setFlowColour({r = r, g = g, b = b})
		elseif type(r)=="table" then
			self:setBaseColour(r)
			self:setFlowColour(r)
		end
	end
	return self
end
function ItemGen:setOrder(order)
	if type(order)=="function" then
		self.order = order
	else
		self.order = function(levels,grade) return order end
	end
	return self
end
function ItemGen:setPlace(place)
	if type(place)== "function" then
		self.place_result = place
	else
		self.place_result = function(levels,grade) return place end
	end
	return self
end
function ItemGen:setLocName(inname,...)
	local arg = {...}
	local rtn = {}
	if not inname then return self end
	if type(inname) == "function" and type(inname(0,0)) == "string" then
		rtn[1] = inname
	elseif type(inname) == "function" and type(inname(0,0)) == "table" then
		
	elseif type(inname)=="table" and inname["grade-1"] then
		rtn[1] = function(levels,grade) return inname["grade-"..grade] end
	elseif type(inname)=="table" and #arg == 0 then
		for _, part in pairs(inname) do
			if type(part) == "function" then
				rtn[#rtn+1] = part
			elseif type(part)=="table" and not #part == 1 then
				rtn[#rtn+1] = function(levels,grade) return inname[grade] end
			elseif type(part)=="string" and string.find(part,".") and (string.find(part,"name") or string.find(part,"description")) then
				rtn[#rtn+1] = function(levels,grade) return {part} end
			else
				rtn[#rtn+1]=function(levels,grade) return part end
			end	
		end
	else
		rtn[1]=function(levels,grade) return inname end
	end
	for _,part in pairs(arg) do
		if type(part) == "function" then
			rtn[#rtn+1] = part
		elseif type(part)=="table" and not #part == 1 then
			rtn[#rtn+1] = function(levels,grade) return inname[grade] end
		elseif type(part)=="string" and string.find(part,".") and (string.find(part,"name") or string.find(part,"description")) then
			rtn[#rtn+1] = function(levels,grade) return {part} end
		else
			rtn[#rtn+1]=function(levels,grade) return part end
		end		
	end
	self.loc_name = function(levels,grade)
		local out = {}
		for _, o in pairs(rtn) do
			out[#out+1]=o(levels,grade)
		end
		return out
	end
	return self
end
function ItemGen:addLocName(key)
	local a = clone_function(self.loc_name)
	local b = function(levels,grade) return {key} end
	if type(key) == "function" then
		b = key
	elseif type(key)=="table" and not #key == 1 then
		b = function(levels,grade) return inname[grade] end
	elseif type(key)=="string" and string.find(key,".") and (string.find(key,"name") or string.find(key,"description")) then
		b = function(levels,grade) return {key} end
	else
		b=function(levels,grade) return key end
	end	
	self.loc_name = clone_function(function(levels,grade) return omni.lib.union(a(levels,grade),{b(levels,grade)}) end)
	return self
end
function ItemGen:setLocDesc(inname,keys)
	if type(inname) == "function" then
		self.loc_desc = inname
	elseif type(inname)=="table" then
		self.loc_desc = function(levels,grade) return inname[grade] end
	else
		self.loc_desc=function(levels,grade) return inname end
	end
	if type(keys) == "function" then
		self.loc_desc_keys = keys
	elseif type(keys)=="table" then
		self.loc_desc_keys = function(levels,grade) return keys end
	else
		self.loc_desc_keys=function(levels,grade) return {keys} end
	end
	return self
end
function ItemGen:addLocDescKey(key)
	local a = clone_function(self.loc_desc_keys)
	local k = key
	if type(key)=="table" then
		k=function(levels,grade) return key end
	elseif type(key)=="string" or type(key)=="number" then
		k=function(levels,grade) return {key} end
	end
	self.loc_desc_keys = function(levels,grade) return omni.lib.union(a(levels,grade),k(levels,grade)) end
	return self
end
function ItemGen:setNameLocType(kind)
	if self.loc_name(0,0) then
		local r =self.loc_name(0,0)
		r[1]=kind.."-name."..r[1]
		return r
	else
		return nil
	end
end
function ItemGen:setDescLocType(kind)
	if self.loc_desc(0,0) then
		local r ={kind.."-name."..self.loc_desc(0,0)}
		if self.loc_desc_keys(0,0) and #self.loc_desc_keys(0,0) > 0 then r[2]=self.loc_desc_keys(0,0) end
		return r
	else
		return nil
	end
end
function ItemGen:generate_item()
		self.rtn[#self.rtn+1] = {
		localised_name = self:setNameLocType("item"),
		localised_description = self:setDescLocType("item"),
		type = self.type,
		name = self.name,
		icons = self.icons(0,0),
		flags = self.flags,
		fuel_value = self.fuel_value,
		fuel_category = self.fuel_category,
		subgroup = self.subgroup(0,0),
		order = self.order(0,0),
		place_result = self.place_result(0,0),
		icon_size = 32,
		stack_size = self.stack_size,
		default_temperature = self.default_temperature,
		heat_capacity=self.heat_capacity,
		base_color=self.base_color,
		flow_color=self.flow_color,
		max_temperature=self.max_temperature,
		pressure_to_speed_ratio = self.pressure_to_speed_ratio,
		flow_to_energy_ratio = self.flow_to_energy_ratio
	}
	return self
end

function ItemGen:return_array()
	self:generate_item()
	return self.rtn
end
function ItemGen:extend()
	self:return_array()
	data:extend(self.rtn)
end

function RecGen:create(mod,name,efficency)
	local r = ItemGen:create(mod,name)
	r.ingredients = function(levels,grade,dif) return nil end
	r.results = function(levels,grade,dif) return nil end
	r.enabled=function(levels,grade) return false end
	r.efficency = efficency
	r.energy_required = function(levels,grade) return 1 end
	r.category = function(levels,grade) return nil end
	r.main_product=function(levels,grade) return nil end
	r.tech = {
		cost = function(levels,grade) return 50 end,
		packs = function(levels,grade) return 1 end,
		time=function(levels,grade) return 20 end,
		upgrade = function(levels,grade) return false end,
		name = function(levels,grade) return self.name end,
		loc_name = function(levels,grade) return nil end,
		loc_desc = function(levels,grade) return nil end,
		icon = function(levels,grade) return nil end,
		prerequisites = function(level,grade) return nil end}
	return setmetatable(r,RecGen)
end


function RecChain:create(mod,name)
	local r = RecGen:create(mod,name,0.5)
	r.tech.cost = function(levels,grade) return 50+50*grade end
	r.tech.packs = function(levels,grade) return math.floor(grade/levels*5+1) end
	r.tech.upgrade = function(levels,grade) return false end
	--r.ingredients=function(levels,grade) return chainIngredients(r,levels,grade) end
	--r.results=function(levels,grade) return wasteYieldResults(r,levels,grade) end
	return setmetatable(r,RecChain)
end

function RecGen:setEnabled(en)
	if type(en)=="function" then
		self.enabled = en
	else
		self.enabled = function(levels,grade) return en end
	end
	return self
end

function RecGen:setItemName(en)
	self.item_name = en or self.name
	return self
end

function RecGen:setItemGen()
	self.item_name = self.name
	return self
end

function RecGen:setIngredients(array,...)
	local arg = {...}
	if #arg > 0 then
		if array.name then
			array = {array}
		elseif type(array[1]) == "string" then
			array={{name=array[1], amount=array[2] or 0, type="item"}}
		end
		for i,v in pairs(arg) do
			local c = v
			if type(v[1])=="string" then c = {name=v[1],amount=v[2],type="item"} end
			array = omni.lib.union(array,{c})
		end
	end
	if type(array)=="table" then
		if array.normal then
			self.ingredients = function(levels,grade, dif) if dif == 0 then return array.normal else return array.expensive end end
		elseif array[1] then
			if type(array[1]) == "string" and type(array[2]) == "number" then
				self.ingredients = function(levels,grade, dif) return {{name=array[1],amount=array[2],type="item"}} end
			elseif type(array[1])=="string" and array[2]==nil then
				self.ingredients = function(levels,grade, dif) return {{name=array[1],amount=1,type="item"}} end
			elseif type(array[1][1])=="table" or array[1].name then
				self.ingredients = function(levels,grade, dif) return array end
			elseif type(array[1][1])=="string" and type(array[1][2])=="number" then
				self.ingredients = function(levels,grade, dif) return array end
			end
		elseif array.name and not array.amount then
			self.ingredients = function(levels,grade, dif) return {{name=array,amount=1,type="item"}} end
		elseif array.name then
			self.ingredients = function(levels,grade, dif) return {array} end
		end
	elseif type(array)=="function" then
		self.ingredients = array
	elseif type(array)=="string" then
		self.ingredients = function(levels,grade, dif) return {{name=array,amount=1}} end
	end
	return self
end
function RecGen:addIngredient(array)
	local tmp = RecGen:create("mah","blah"):
		setIngredients(array)
	local a = clone_function(tmp.ingredients)
	local b = clone_function(self.ingredients)
	self.ingredients = function(levels,grade) return omni.table.union(a(levels,grade),b(levels,grade)) end
	return self
end
function RecGen:setResults(array,...)	local arg = {...}
	if #arg > 0 then
		if array.name then
			array = {array}
		elseif type(array[1]) == "string" then
			array={name=array[1], amount=array[2] or 0, type="item"}
		end
		for i,v in pairs(arg) do
			local c = v
			if type(v[1])=="string" then c = {name=v[1],amount=v[2],type="item"} end
			array = omni.lib.union(array,{c})
		end
	end
	if type(array)=="table" then
		if array.normal then
			self.results = function(levels,grade, dif) if dif == 0 then return array.normal else return array.expensive end end
		elseif array[1] then
			if type(array[1]) == "string" and type(array[2]) == "number" then
				self.results = function(levels,grade, dif) return {{name=array[1],amount=array[2],type="item"}} end
			elseif type(array[1])=="string" and array[2]==nil then
				self.results = function(levels,grade, dif) return {{name=array[1],amount=1,type="item"}} end
			elseif type(array[1][1])=="table" or array[1].name then
				self.results = function(levels,grade, dif) return array end
			end
		elseif array.name then
			self.results = function(levels,grade, dif) return {
			{name=array.name,amount=array.amount,type=array.type or "item",amount_min=array.amount_min,amount_max=array.amount_max,probability=array.probability}
			} end
		end
	elseif type(array)=="function" then
		self.results = array
	elseif type(array)=="string" then
		self.results = function(levels,grade, dif) return {{name=array,amount=1,type="item"}} end
	end
	return self
end
function RecGen:addResult(array)
	local tmp = RecGen:create("mah","blah"):
		setResults(array)
	local a = clone_function(tmp.ingredients)
	local b = clone_function(self.results)
	self.results = function(levels,grade) return omni.table.union(a(levels,grade),b(levels,grade)) end
	return self
end
function RecGen:setEnergy(tid)
	if type(tid)~= "function" then
		self.energy_required=function(levels,grade) return tid end
	else
		self.energy_required=tid
	end
	return self
end
function RecGen:setCategory(cat)
	if type(cat)~= "function" then
		self.category=function(levels,grade) return cat end
	else
		self.category=cat
	end
	return self
end
function RecGen:setMain(main)
	if type(main)~= "function" then
		self.main_product = function(levels,grade) return main end
	else
		self.main_product = main
	end
	
	return self
end
function RecGen:generate_recipe()
	local res = self.results(0,0)
	if #res == 1 and not self.set_icon then
		self.main_product=function(levels,grade) return self.results(0,0,0)[1].name end
	end
	if (#res == 1 and not omni.lib.find_prototype(res[1].name)) or (self.item_name and not omni.lib.find_prototype(self.item_name)) then
		local it = ItemGen:create(self.mod,self.item_name or res[1].name):
		setIcons(self.icons(0,0)):
		setSubgroup(self.subgroup(0,0)):
		setStacksize(self.stack_size):
		setFuelValue(self.fuel_value):
		setOrder(self.order(0,0)):
		setPlace(self.place_result(0,0)):
		setFlags(self.flags):
		setLocName(self.loc_name(0,0)):
		setLocDesc(self.loc_desc(0,0))
		if self.fuel_category then it:setFuelCategory(self.fuel_category) end
		if self.type == "fluid" then
			it:fluid():
			setMaxTemp(self.max_temperature):
			setCapacity(self.heat_capacity):
			setBaseColour(self.base_color):
			setFlowColour(self.flow_color)			
		end
		it:extend()
	end
	if self.main_product then
		if data.raw.item[self.main_product(0,0)] then
			local item = data.raw.item[self.main_product(0,0)]
			if item.icons then
				self.icons = function(levels,grade) return item.icons end
			elseif item.icon then
				self.icons = function(levels,grade) return {{icon = item.icon}} end
			end
		elseif data.raw.fluid[self.main_product(0,0)] then
			local fluid = data.raw.fluid[self.main_product(0,0)]
			if fluid.icons then
				self.icons = function(levels,grade) return fluid.icons end
			elseif fluid.icon then
				self.icons = function(levels,grade) return {{icon = fluid.icon}} end
			end
		end
	end
	if self.tech.name(0,0) ~= nil and not self.enabled(0,0) then
		if not data.raw.technology[self.tech.name(0,0)] and self.tech.icon(0,0)~= nil then
			self.rtn[#self.rtn+1]=TechGen:create(self.mod,self.tech.name(0,0)):
			setCost(self.tech.cost(0,0)):
			setPacks(self.tech.packs(0,0)):
			setTime(self.tech.time(0,0)):
			setIcon(self.tech.icon(0,0)):
			setUpgrade(self.tech.upgrade(0,0) or false):
			addUnlock(self.name):
			setPrereq(self.tech.prerequisites(0,0)):
			setLocDesc(self.tech.loc_desc(0,0)):
			setLocName(self.tech.loc_name(0,0)):
			return_array()[1]
		else
			omni.lib.add_unlock_recipe(self.tech.name(0,0), self.name)
		end
	end
	if self.category(0,0) and not data.raw["recipe-category"][self.category(0,0)] then
		data:extend({
			{
				type = "recipe-category",
				name = self.category(0,0),
			}
		})
	end
	self.rtn[#self.rtn+1] ={
		type = "recipe",
		name = self.name,
		localised_name = self:setNameLocType("recipe"),
		localised_description = self:setDescLocType("recipe"),
		category = self.category(0,0),
		subgroup = self.subgroup(0,0),
		normal = {
			ingredients=table.deepcopy(self.ingredients(0,0,0)),
			results=table.deepcopy(self.results(0,0,0)),
			enabled = self.enabled(0,0),
			main_product = self.main_product(0,0),
			energy_required = self.energy_required(0,0) or 1.5,
		},
		expensive = {
			ingredients=table.deepcopy(self.ingredients(0,0,1)),
			results=table.deepcopy(self.results(0,0,1)),
			enabled = self.enabled(0,0),
			main_product = self.main_product(0,0),
			energy_required = self.energy_required(0,0) or 1.5,
		},
		order = "a[angelsore1-crushed]",
		icons = self.icons(0,0),
		icon_size = 32,
	}
	return self
end
function RecGen:marathon()
	omni.marathon.exclude_recipe(self.name)
	return self
end
function RecGen:return_array()
	self:generate_recipe()
	return self.rtn
end
function RecGen:extend()
	self:return_array()
	data:extend(self.rtn)
end

function RecChain:setLevel(lvl)
	self.levels=lvl
	return self
end

function RecGen:setTechName(name)
	if type(name)=="function" then
		self.tech.name = name
	elseif type(name)=="string" then
		self.tech.name=function(levels,grade) return name end
	else
		self.tech.name=function(levels,grade) return self.name end
	end
	return self
end
function RecGen:setTechLocName(inname,...)
	local arg = {...}
	local rtn = {}
	if type(inname) == "function" then
		rtn[1] = inname
	elseif type(inname)=="table" and inname["grade-1"] then
		rtn[1] = function(levels,grade) return inname["grade-"..grade] end
	elseif type(inname)=="table" and #arg == 0 then
		for _, part in pairs(inname) do
			if type(part) == "function" then
				rtn[#rtn+1] = part
			elseif type(part)=="table" and not #part == 1 then
				rtn[#rtn+1] = function(levels,grade) return inname[grade] end
			elseif type(part)=="string" and string.find(part,".") and (string.find(part,"name") or string.find(part,"description")) then
				rtn[#rtn+1] = function(levels,grade) return {part} end
			else
				rtn[#rtn+1]=function(levels,grade) return part end
			end	
		end
	else
		rtn[1]=function(levels,grade) return inname end
	end
	for _,part in pairs(arg) do
		if type(part) == "function" then
			rtn[#rtn+1] = part
		elseif type(part)=="table" and not #part == 1 then
			rtn[#rtn+1] = function(levels,grade) return inname[grade] end
		elseif type(part)=="string" and string.find(part,".") and (string.find(part,"name") or string.find(part,"description")) then
			rtn[#rtn+1] = function(levels,grade) return {part} end
		else
			rtn[#rtn+1]=function(levels,grade) return part end
		end		
	end
	self.tech.loc_name = function(levels,grade)
		local out = {}
		for _, o in pairs(rtn) do
			out[#out+1]=o(levels,grade)
		end
		return out
	end
	return self
end
function RecGen:addTechLocName(key)
	local a = clone_function(self.tech.loc_name)
	local b = function(levels,grade) return {key} end
	if type(key) == "function" then
		b = key
	elseif type(key)=="table" and not #key == 1 then
		b = function(levels,grade) return inname[grade] end
	elseif type(key)=="string" and string.find(key,".") and (string.find(key,"name") or string.find(key,"description")) then
		b = function(levels,grade) return {key} end
	else
		b=function(levels,grade) return key end
	end	
	self.tech.loc_name = clone_function(function(levels,grade) return omni.lib.union(a(levels,grade),{b(levels,grade)}) end)
	return self
end
function RecGen:setTechLocDesc(inname,keys)
		if type(inname) == "function" then
		self.tech.loc_desc = inname
	elseif type(inname)=="table" then
		self.tech.loc_desc = function(levels,grade) return inname[grade] end
	else
		self.tech.loc_desc=function(levels,grade) return inname end
	end
	if type(keys) == "function" then
		self.tech.loc_desc_keys = keys
	elseif type(keys)=="table" then
		self.tech.loc_desc_keys = function(levels,grade) return keys end
	else
		self.tech.loc_desc_keys=function(levels,grade) return {keys} end
	end
	return self
end
function RecGen:setTechUpgrade(value)
	if type(value)~= "function" then
		self.tech.upgrade = function(levels,graede) return value == nil or value end
	else
		self.tech.upgrade = value
	end
	return self
end
function RecGen:setTechCost(cost)
	if type(cost)=="number" then
		self.tech.cost = function(levels,grade) return cost end
	elseif type(cost)=="function" then
		self.tech.cost = cost
	end
	return self
end
function RecGen:setTechIcon(mod,icon)
	if icon then
		self.tech.icon = function(levels,grade) return "__"..mod.."__/graphics/technology/"..icon..".png" end
	elseif type(mod)=="string" then
		if not string.match(mod, "%_%_(.-)%_%_") then
			local proto = omni.lib.find_prototype(mod)
			if proto then
				self.tech.icon=function(levels,grade) return proto.icon end
			else
				self.tech.icon=function(levels,grade) return nil end
			end
		else
			self.tech.icon=function(levels,grade) return mod end
		end
	elseif type(mod)=="function" then
		self.tech.icon=mod
	end
	return self
end
function RecGen:setTechPacks(cost)
	if type(cost)=="number" then
		self.tech.packs = function(levels,grade) return cost end
	elseif type(cost)=="function" then
		self.tech.packs = cost
	end
	return self
end
function RecGen:setTechTime(t)
	if type(t)=="number" then
		self.tech.time = function(levels,grade) return t end
	elseif type(t)=="function" then
		self.tech.time = t
	end
	return self
end
function RecGen:setTechPrereq(prereq)
	if type(prereq)=="table" then
		self.tech.prerequisites = function(level,grade) return prereq end
	elseif type(prereq)=="string" then
		self.tech.prerequisites = function(level,grade) return {prereq} end
	elseif type(prereq)=="function" then
		self.tech.prerequisites = prereq
	end
	return self
end

function RecChain:setTechSuffix(suffix)
	self.tech.suffix = suffix
	return self
end
function RecChain:setTechPrefix(prefix)
	self.tech.prefix = prefix
	return self
end

function RecChain:setTechCircumfix(prefix,suffix)
	self.chain.tech.suffix = suffix
	self.chain.tech.prefix = prefix
	return self
end

function RecChain:generate_chain()
	local array = {}
	local m = self.levels
	local res = self.results(self.levels,1)
	if (#res == 1 and not omni.lib.find_prototype(res[1].name)) or (self.main_product and not omni.lib.find_prototype(self.main_product(0,0)))
		or (self.item_name and not omni.lib.find_prototype(self.item_name)) then
		local it = ItemGen:create(self.mod,self.item_name or res[1].name or self.main_product):
		setIcons(self.icons(0,0)):
		setSubgroup(self.subgroup(0,0)):
		setStacksize(self.stack_size):
		setFuelValue(self.fuel_value):
		setOrder(self.order(0,0)):
		setPlace(self.place_result(0,0)):
		setFlags(self.flags):
		setLocName(self.loc_name(0,0)):
		setLocDesc(self.loc_desc(0,0))
		if self.fuel_category then it:setFuelCategory(self.fuel_category) end
		if self.type == "fluid" then
			it:fluid():
			setMaxTemp(self.max_temperature):
			setCapacity(self.heat_capacity):
			setBaseColour(self.base_color):
			setFlowColour(self.flow_color)			
		end
		it:extend()
	end
	
	for i = 1, self.levels do		
		local techname = self.tech.name(m,i) or self.name
		if self.tech.prefix ~= "" and self.tech.prefix ~= nil then techname=self.tech.prefix.."-"..techname end
		if self.tech.suffix ~= "" and self.tech.suffix ~= nil then techname=techname.."-"..self.tech.suffix end
		local r = RecGen:create(self.mod,"omnirec-"..self.name.."-"..ord[i]):
		setCategory(self.category):
		setSubgroup(self.subgroup(self.levels,i)):
		setLocName(self.loc_name(m,i)):
		setLocDesc(self.loc_desc(m,i)):
		setIcons(self.icons(m,i)):
		setEnabled(self.enabled(m,i)):
		setEnergy(self.energy_required(self.levels,i)):
		setTechCost(self.tech.cost(self.levels,i)):
		setTechPacks(self.tech.packs(self.levels,i)):
		setTechUpgrade(i>1):
		setTechIcon(self.tech.icon(levels,i)):
		setTechLocName(self.tech.loc_name(levels,grade)):
		setTechLocDesc(self.tech.loc_desc,self.tech.loc_desc_keys):
		setTechName("omnitech-"..techname.."-"..i)
		if self.tech.icon(levels,i) then
			r:setTechIcon(self.tech.icon(levels,i))
		else
			r:setTechIcon(self.mod,self.tech.name)
		end
		if self.loc_name(m,i)~= nil then r:addLocName(i) end
		if self.tech.loc_name(levels,grade) ~= nil then r:addTechLocName(i) end
		
		local prq = self.tech.prerequisites(m,i)
		if (not prq or #prq == 0) and i > 1 then prq={"omnitech-"..techname.."-"..i-1} end
		r:setTechPrereq(prq)
		if not self.set_icon then
			if self.main_product(0,0) then
				self:setIcons(self.main_product(0,0))
			end
		end
		--r:setIcons(self.icons(m,i))
		
		if mods["omnimatter_marathon"] then omni.marathon.exclude_recipe(r.name) end
		r:setIngredients(self.ingredients(self.levels,i))
		r:setResults(self.results(self.levels,i))
		--if #self.chain.output.yield.items == 1 then self:setMain(self.chain.output.yield.items[1]) end
		r:return_array()
		array = table.deepcopy(omni.lib.union(array,r.rtn))
		
		--Tech generation
		--[[
		local techname = self.tech.name
		if self.tech.prefix then techname=self.tech.prefix..techname end
		if self.tech.suffix then techname=techname..self.tech.suffix end
		local t = TechGen:create(self.mod,"omnirec-"..techname.."-"..ord[i]):
		set_packs(self.tech.packs(self.levels,i)):
		set_cost(self.tech.cost(self.levels,i))]]
	end
	self.rtn = array
	return self
end
function RecChain:return_array()
	self:generate_chain()
	return self.rtn
end
function RecChain:extend()
	self:return_array()
	data:extend(self.rtn)
end

function TechGen:create(mod,name)
	local m = "__omnimatter_"..mod.."__"
	if mod == nil or mod == "omnimatter" then m = "__omnimatter__" end
	return setmetatable({
		mod = mod,
		name=name,
		icon = m.."/graphics/technology/"..name..".png",
		rtn = {},
		cost = 50,
		packs = 1,
		unlock={},
		upgrade = false,
		prereq={},
		time = 20,
		type="technology",
	},TechGen)
end
function TechGen:setName(name)
	self.name = name
	return self
end
function TechGen:setIcon(m)
	self.icon = m
	return self
end
function TechGen:setLocName(n,m)
	self.loc_name = n
	self.loc_name_keys = m
	return self
end
function TechGen:setLocDesc(n,m)
	self.loc_desc =n
	self.loc_desc_keys = m
	return self
end
function TechGen:setPacks(p)
	self.packs = p
	return self
end
function TechGen:setCost(c)
	self.cost = c
	return self
end
function TechGen:setTime(t)
	self.time = t
	return self
end
function TechGen:setPrereq(t)
	self.prereq = t
	return self
end
function TechGen:setUpgrade(value)
	self.upgrade = value == nil or value
	return self
end
function TechGen:addUnlock(unlock)
	if type(unlock)=="string" then
		table.insert(self.unlock,unlock)
	elseif type(unlock)=="table" then
		self.unlock=omni.lib.union(self.unlock,unlock)
	end
	return self
end
function TechGen:generate_tech()
	local c = {}
	local add_cost = 1
	for i=1,self.packs do
		if omni.sciencepacks[i] then
			table.insert(c,{omni.sciencepacks[i],1})
		else
			add_cost = add_cost *2
		end
	end
	local u = {}
	for _, rec in pairs(self.unlock) do
		u[#u+1]={
			type = "unlock-recipe",
			recipe = rec
		}
	end
	local tech = { 
	name = self.name,
    --localised_name = self.locname(0,0),
	--localised_description = self.locdesc(0,0),
	type = "technology",
	icon = self.icon,
	upgrade = self.upgrade,
	icon_size = 128,
	prerequisites = self.prereq,
	effects =u,
	unit  =
	{
	  count = omni.lib.round(self.cost*add_cost),
	  ingredients = c,
	  time = self.time
	},
	order = "c-a"
	}
	if self.loc_name and #self.loc_name>0 then
		tech.localised_name = self.loc_name
		tech.localised_name[1]="technology-name."..tech.localised_name[1]
	end
	if self.loc_desc and self.loc_desc then tech.localised_description = {"technology-description."..self.loc_desc,self.loc_desc_keys} end
	self.rtn[#self.rtn+1] = tech
end
function TechGen:return_array()
	self:generate_tech()
	return self.rtn
end
function TechGen:extend()
	data:extend(self:return_array())
end

function setBuildingParameters(b,subpart)
	b.type = "assembling-machine"
	b.fast_replaceable_group=function(levels,grade) return "assembling-machine" end
	b.max_health = function(levels,grade) return 300 end
	b.size = function(levels,grade) return 1.5 end
	b.mining_time = function(levels,grade) return 1 end
	b.module =
    {
      slots = function(levels,grade) return 3 end,
	  effects = function(levels,grade) return {"consumption", "speed", "pollution", "productivity"} end
    }
	b.crafting_speed=function(levels,grade) return 1 end
	b.source_inventory_size = function(levels,grade) return 7 end
	b.ingredient_count = function(levels,grade) return 7 end
	b.energy_source =
    {
	  type = "electric",
	  usage_priority = "secondary-input",
	  emissions = 0.04 / 3.5
	}
	b.energy_usage = function(levels,grade) return "150kW" end
	b.animation = function(levels,grade) return {} end
	b.vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 }
    b.working_sound = {
      sound = function(levels,grade) return {
        {
          filename = "__base__/sound/assembling-machine-t1-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t1-2.ogg",
          volume = 0.8
        },
      } end,
      idle_sound = function(levels,grade) return { filename = "__base__/sound/idle1.ogg", volume = 0.6 } end,
      apparent_volume = function(levels,grade) return 2 end,
    }
	b.fluid_boxes = function(levels,grade) return nil end
	b.input_fluid_box = function(levels,grade) return nil end
	b.flags = {"placeable-neutral", "player-creation"}
	b.corpse = "big-remnants"
	b.mining_speed = 0.5
	b.mining_power = 3
	b.overlay={}
	b.place_result = function(levels,grade) return b.name end
    b.resource_searching_radius = 2.49
    b.vector_to_place_result = {0, -1.85}
	b.crafting_categories = function(levels,grade) return nil end
	b.working_visualisations = function(levels,grade) return nil end
	return b
end

function BuildGen:create(mod,name)
	local b = RecGen:create(mod,name)
	return setmetatable(setBuildingParameters(b),BuildGen)
end

function BuildGen:setDrill()
	self.type = "mining-drill"
	return self
end
function BuildGen:setFurnace()
	self.type = "furnace"
	return self
end
function BuildGen:setReplace(group)
	if type(group) == "function" then
		self.fast_replaceable_group = group
	else
		self.fast_replaceable_group = function(levels,grade) return group end
	end
	return self
end
function BuildGen:setHealth(h)
	if type(h) == "function" then
		self.health = h
	else
		self.health = function(levels,grade) return h end
	end
	return self
end
function BuildGen:setSize(h,prop)
	if type(h) == "function" then
		self.size = h
	else
		self.size = function(levels,grade) return h/2 end
	end
	return self
end
function BuildGen:setModSlots(h)
	if type(h) == "function" then
		self.module.slots = h
	else
		self.module.slots = function(levels,grade) return math.floor(h) end
	end
	return self
end
function BuildGen:setModEffects(h)
	if type(h)=="string" then
		self.module.effects = function(levels,grade) return {h} end
	elseif type(h) == "table" then
		self.module.effects = function(levels,grade) return h end
	else
		self.module.effects = function(levels,grade) return h end
	end
	return self
end
function BuildGen:setSpeed(h)
	if type(h) == "function" then
		self.crafting_speed = h
	else
		self.crafting_speed = function(levels,grade) return h end
	end
	return self
end
function BuildGen:setInventory(h)
	if type(h) == "function" then
		self.source_inventory_size = h
		self.ingredient_count=h
	else
		self.source_inventory_size = function(levels,grade) return h end
		self.ingredient_count=function(levels,grade) return h end
	end
	return self
end
function BuildGen:setBurner(efficiency,size)
	self.energy_source = {type = "burner",
      effectivity = efficiency or 0.5,
      fuel_inventory_size = size or 1,
      emissions = 0.01,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {1.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      }}
	self:addBurnerIcon():setName("burner-"..self.name)
	return self
end
function BuildGen:setBurnEfficiency(eff)
	if type(eff) == "function" then
		self.energy_source.effectivity = eff
	else
		self.energy_source.effectivity = function(levels,grade) return eff end
	end
	return self
end
function BuildGen:setBurnSlots(slots)
	if type(slots) == "function" then
		self.energy_source.fuel_inventory_size = slots
	else
		self.energy_source.fuel_inventory_size = function(levels,grade) return slots end
	end
	return self
end
function BuildGen:addSmoke()
	self.smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {1.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      }
	return self
end

function BuildGen:setUsage(operation)
	if type(operation)=="function" then
		self.energy_usage = operation
	elseif type(operation)=="string" then
		self.energy_usage = function(levels,grade) return operation end
	elseif type(operation)=="number" then
		self.energy_usage = function(levels,grade) return operation.."kW" end
	end
	return self
end

function BuildGen:setAnimation(e)
	if type(e)=="function" then
		self.animation = e
	else
		self.animation = function(levels,grade) return e end
	end
	return self
end	
function BuildGen:setWorkVis(e)
	if type(e)=="function" then
		self.working_visualisations = e
	else
		self.working_visualisations = function(levels,grade) return e end
	end
	return self
end	
function BuildGen:setSoundImpact(e)
	self.vehicle_impact_sound = { filename = e, volume = 0.65 }
	return self
end	
function BuildGen:setSoundWorking(e,i,mod)
	if type(e)=="string" then
		self.working_sound.sound = function(levels,grade) return {filename="__"..(mod or self.mod).."__/sound/"..e..".ogg",volume = i or 0.8} end
	elseif type(e) == "table" then
		self.working_sound.sound = function(levels,grade) return e end
	else
		self.working_sound.sound = e
	end
	return self
end
function BuildGen:setSoundIdle(e,i,mod)
	if type(e)=="string" then
		self.working_sound.idle_sound = function(levels,grade) return {filename="__"..(mod or self.mod).."__/sound/"..e..".ogg",volume = i or 0.6} end
	elseif type(e) == "table" then
		self.working_sound.idle_sound = function(levels,grade) return e end
	else
		self.working_sound.idle_sound = e
	end
	return self
end
function BuildGen:setSoundVolume(e)
	if type(e)~="function" then
		self.working_sound.apparent_volume = function(levels,grade) return e end
	else
		self.working_sound.apparent_volume = e
	end
	return self
end
function BuildGen:returnSound(levels,grade)	
	return {
		sound = self.working_sound.sound(levels,grade),
		idle_sound = self.working_sound.idle_sound(levels,grade),
		apparent_volume = self.working_sound.apparent_volume(levels,grade)
	}
end
function BuildGen:setFluidBox(s)
	if type(s) == "table" then
		self.fluid_boxes = function(levels,grade) return s end
	elseif type(s)=="string" then
		self.fluid_boxes = function(levels,grade) return omni.lib.fluid_box_conversion(s) end
		
		local spl = omni.lib.split(s,".")
		self:setSize(#spl)
	elseif type(s) == "function" then
		self.fluid_boxes=s
	end
	return self
end	
function BuildGen:setFluidInput(s)
	self.input_fluid_box = s
	return self
end	
function BuildGen:setFlags(s)
	if type(s)=="string" then
		self.flags = {s}
	else
		self.flags = s	
	end
	return self
end
function BuildGen:setCorpse(s)
	if string.find(s,"remnants") then
		self.corpse = s
	else
		self.corpse = s.."-remnants"	
	end
	return self
end	
function BuildGen:setMiningSpeed(s)
	self.mining_speed = s
	return self
end	
function BuildGen:setMiningPower(s)
	self.mining_power = s
	return self
end	
function BuildGen:setMiningRadius(s)
	self.resource_searching_radius = s-0.01
	return self
end
function BuildGen:setMiningDiameter(s)
	self.resource_searching_radius = s/2-0.01
	return self
end
function BuildGen:setPlaceShift(s)
	self.vector_to_place_result = s/2-0.01
	return self
end
function BuildGen:setMiningTime(s)
	self.mining_time = s
	return self
end
function BuildGen:setSound(s)
	self.mining_time = s
	return self
end
function BuildGen:setCrafting(s)
	if type(s)=="table" then
		self.crafting_categories = function(levels,grade) return s end
	elseif type(s)=="string" then
		self.crafting_categories = function(levels,grade) return {s} end
	else
		self.crafting_categories = s
	end
	return self
end

function BuildGen:generateBuilding()
	local size = self.size(0,0)
	local source = {}
	for name,f in pairs(self.energy_source) do
		if type(f)=="function" then
			source[name]=f(0,0)
		else
			source[name]=f
		end
	end
	if self.type=="furnace" then self.source_inventory_size = function(levels,grade) return 1 end end
	self.rtn[#self.rtn+1]= {	
		type = self.type,
		name = self.name,
		icon_size = 32,
		order=self.order(0,0),
		localised_name = self:setNameLocType("entity"),
		localised_description = self:setDescLocType("entity"),
		icons = self.icons(0,0),
		flags = self.flags,
		minable = {mining_time = self.mining_time(0,0), result = self.name},
		fast_replaceable_group = self.fast_replaceable_group(0,0),
		max_health = self.max_health(0,0),
		corpse = self.corpse,
		dying_explosion = "medium-explosion",
		collision_box = {{-size+0.3, -size+0.3}, {size-0.3, size-0.3}},
		selection_box = {{-size, -size}, {size, size}},
		module_specification =
		{
		  module_slots = self.module.slots(0,0)
		},
		allowed_effects = self.module.effects(0,0),
		crafting_categories = self.crafting_categories(0,0),
		crafting_speed = self.crafting_speed(0,0),
		source_inventory_size = self.source_inventory_size(0,0),
		energy_source = source,
		smoke = self.smoke,
		energy_usage = self.energy_usage(0,0),
		ingredient_count = self.ingredient_count(0,0),
		animation =self.animation(0,0),
		working_visualisations = self.working_visualisations(0,0),
		vehicle_impact_sound =  self.vehicle_impact_sound,
		working_sound =self:returnSound(0,0),
		fluid_boxes = self:fluid_boxes(0,0),
		result_inventory_size = 1,
    }
	if self.overlay.name then
		self.rtn[#self.rtn].animation.layers[#self.rtn[#self.rtn].animation.layers+1] = table.deepcopy(self.rtn[#self.rtn].animation.layers[1])
		self.rtn[#self.rtn].animation.layers[#self.rtn[#self.rtn].animation.layers].filename = "__"..self.mod.."__/graphics/entity/buildings/"..self.overlay.name..".png"
		self.rtn[#self.rtn].animation.layers[#self.rtn[#self.rtn].animation.layers].tint = omni.tint_level[self.overlay.level]
	end
	local stuff = RecGen:create(self.mod,self.name):
	setIngredients(self.ingredients(0,0)):
	setResults(self.name):
	setIcons(self.icons(0,0)):
	setQuickbar():
	setEnergy(self.energy_required(0,0)):
	setCategory(self.category(0,0)):
	setLocName(self.loc_name(0,0)):
	setLocDesc(self.loc_desc(0,0)):
	setEnabled(self.enabled(0,0)):
	setMain(self.main_product(0,0)):
	setPlace(self.place_result(0,0)):
	setTechName(self.tech.name(0,0)):
	setTechUpgrade(self.tech.upgrade(0,0)):
	setTechCost(self.tech.cost(0,0)):
	setTechIcon(self.tech.icon(0,0)):
	setTechPacks(self.tech.packs(0,0)):
	setSubgroup(self.subgroup(0,0)):
	setTechTime(self.tech.time(0,0)):
	setTechLocName(self.tech.loc_name(0,0)):
	setTechLocDesc(self.tech.loc_desc(0,0)):
	setTechPrereq(self.tech.prerequisites(0,0)):return_array()
	for _, p in pairs(stuff) do
		self.rtn[#self.rtn+1] = table.deepcopy(p)
	end
end
function BuildGen:return_array()
	self:generateBuilding()
	return self.rtn
end
function BuildGen:extend()
	data:extend(self:return_array())
end
function BuildChain:create(mod,name)
	local b = RecChain:create(mod,name)
	return setmetatable(setBuildingParameters(b),BuildChain)
end
function BuildChain:setInitialBurner(efficiency,size)
	self.burner = {type = "burner",
      effectivity = efficiency or 0.5,
      fuel_inventory_size = size or 1,
      emissions = 0.01,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 5,
          position = {1.0, -0.8},
          starting_vertical_speed = 0.08,
          starting_frame_deviation = 60
        }
      }}
	return setmetatable(setBuildingParameters(b),BuildChain)
end
function BuildChain:generate_building_chain()
	local levels = tonumber(self.levels)
	
	if self.burner then
	
	end
	for i=1,levels do
		local tname = self.tech.name(levels,i) or self.name
		if not data.raw.technology[tname] then
			if self.tech.prefix then tname = self.tech.prefix.."-"..tname end
			if self.tech.suffix then tname = tname.."-"..self.tech.suffix end
		end

		if self.tech.name(levels,i) == self.tech.name(levels,i+1) then
			local d = 0
			for j=i,2,-1 do
				if self.tech.name(levels,j) ~= self.tech.name(levels,j-1) then
					d=j-1
					break
				end
			end
			tname = tname.."-"..i-d
		end
		
		local ing = self.ingredients(levels,i)
		if i>1 and not omni.lib.is_in_table(self.name.."-"..i,ing) then ing[#ing+1]={name=self.name.."-"..i-1,amount=1,type="item"} end
		if i>1 and mods["omnimatter_marathon"] then omni.marathon.equalize(self.name.."-"..i-1,self.name.."-"..i) end
		local stuff = BuildGen:create(self.mod,self.name.."-"..i):
		setIngredients(ing):
		setResults(self.name.."-"..i):
		setPlace(self.name.."-"..i):
		setEnergy(self.energy_required(levels,i)):
		setUsage(self.energy_usage(levels,i)):
		setCrafting(self.category(levels,i)):
		setLocName(self.loc_name(levels,i)):
		addLocName(i):
		setLocDesc(self.loc_desc(levels,i)):
		setSubgroup(self.subgroup(levels,i)):
		setMain(self.main_product(levels,i)):
		setIcons(self.icons(levels,i)):
		addIconLevel(i):
		setSize(function(levels,grade) return self.size(self.levels,i) end):
		setTechName(tname):
		setReplace(self.fast_replaceable_group(levels,i)):
		setTechUpgrade(self.tech.upgrade(levels,i)):
		setTechCost(self.tech.cost(levels,i)):
		setTechIcon(self.tech.icon(levels,i)):
		setEnabled(self.enabled(levels,i)):
		setTechPacks(self.tech.packs(levels,i)):
		setTechTime(self.tech.time(levels,i)):
		setTechLocName(self.tech.loc_name(levels,i)):
		setTechPrereq(self.tech.prerequisites(levels,i)):
		setOverlay(self.overlay.name,i+1):
		setCrafting(self.crafting_categories(levels,i)):
		setFluidBox(self.fluid_boxes):
		setSpeed(self.crafting_speed(levels,i)):
		setSoundIdle(self:returnSound(levels,i).idle_sound):
		setSoundWorking(self:returnSound(levels,i).sound):
		setSoundVolume(self:returnSound(levels,i).volume):
		setAnimation(self.animation(levels,i)):
		setWorkVis(self.working_visualisations(levels,i))
		if self.tech.loc_name(levels,i) then
			stuff:addTechLocName(i)
		end
		
		for _,m in pairs(stuff:return_array()) do
			self.rtn[#self.rtn+1]=table.deepcopy(m)
		end
	end
end


	
function BuildGen:setOverlay(n,l)
	if n then
		self.overlay={name = n, level = l}
	end
	return self
end
function BuildChain:return_array()
	self:generate_building_chain()
	return self.rtn
end
function BuildChain:extend()
	self:return_array()
	log("test1")
	data:extend(self.rtn)
	log("test2")
end

function BotGen:create(mod,name)
	local b = BuildGen:create(mod,name)
	b.max_payload_size = function(levels,grade) return 1 end
	b.speed = function(levels,grade) return 1 end
	b.transfer_distance = function(levels,grade) return 0.5 end
    b.max_energy = function(levels,grade) return "1MJ" end
    b.energy_per_tick = function(levels,grade) return "0.075kJ" end
    b.speed_multiplier_when_out_of_energy = function(levels,grade) return 0.5 end
    b.energy_per_move = function(levels,grade) return "7.5kJ" end
    b.min_to_charge = function(levels,grade) return 0.4 end
    b.max_to_charge = function(levels,grade) return 0.95 end
    b.working_light = function(levels,grade) return {intensity = 0.8, size = 3} end
	b.smoke = function(levels,grade) return {
      filename = "__base__/graphics/entity/smoke-construction/smoke-01.png",
      width = 39,
      height = 32,
      frame_count = 19,
      line_length = 19,
      shift = {0.078125, -0.15625},
      animation_speed = 0.3,
    } end
    b.sparks = function(levels,grade) return {
      {
        filename = "__base__/graphics/entity/sparks/sparks-01.png",
        width = 39,
        height = 34,
        frame_count = 19,
        line_length = 19,
        shift = {-0.109375, 0.3125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3,
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-02.png",
        width = 36,
        height = 32,
        frame_count = 19,
        line_length = 19,
        shift = {0.03125, 0.125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3,
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-03.png",
        width = 42,
        height = 29,
        frame_count = 19,
        line_length = 19,
        shift = {-0.0625, 0.203125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3,
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-04.png",
        width = 40,
        height = 35,
        frame_count = 19,
        line_length = 19,
        shift = {-0.0625, 0.234375},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3,
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-05.png",
        width = 39,
        height = 29,
        frame_count = 19,
        line_length = 19,
        shift = {-0.109375, 0.171875},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3,
      },
      {
        filename = "__base__/graphics/entity/sparks/sparks-06.png",
        width = 44,
        height = 36,
        frame_count = 19,
        line_length = 19,
        shift = {0.03125, 0.3125},
        tint = { r = 1.0, g = 0.9, b = 0.0, a = 1.0 },
        animation_speed = 0.3,
      },
    } end
    b.idle = function(levels,grade) return {
      filename = "__base__/graphics/entity/construction-robot/construction-robot.png",
      priority = "high",
      line_length = 16,
      width = 32,
      height = 36,
      frame_count = 1,
      shift = {0, -0.15625},
      direction_count = 16,
      hr_version = {
        filename = "__base__/graphics/entity/construction-robot/hr-construction-robot.png",
        priority = "high",
        line_length = 16,
        width = 66,
        height = 76,
        frame_count = 1,
        shift = util.by_pixel(0,-4.5),
        direction_count = 16,
        scale = 0.5
      }
    } end
	b.shadow_idle = function(levels,grade) return {
      filename = "__base__/graphics/entity/construction-robot/construction-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 50,
      height = 24,
      frame_count = 1,
      shift = {1.09375, 0.59375},
      direction_count = 16,
      hr_version = {
        filename = "__base__/graphics/entity/construction-robot/hr-construction-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 104,
        height = 49,
        frame_count = 1,
        shift = util.by_pixel(33.5, 18.75),
        direction_count = 16,
        scale = 0.5
      }
    } end
	b.in_motion = function(levels,grade) return {
      filename = "__base__/graphics/entity/construction-robot/construction-robot.png",
      priority = "high",
      line_length = 16,
      width = 32,
      height = 36,
      frame_count = 1,
      shift = {0, -0.15625},
      direction_count = 16,
      y = 36,
      hr_version = {
        filename = "__base__/graphics/entity/construction-robot/hr-construction-robot.png",
        priority = "high",
        line_length = 16,
        width = 66,
        height = 76,
        frame_count = 1,
        shift = util.by_pixel(0, -4.5),
        direction_count = 16,
        y = 76,
        scale = 0.5
      }
    } end
	b.shadow_in_motion = function(levels,grade) return {
      filename = "__base__/graphics/entity/construction-robot/construction-robot-shadow.png",
      priority = "high",
      line_length = 16,
      width = 50,
      height = 24,
      frame_count = 1,
      shift = {1.09375, 0.59375},
      direction_count = 16,
      hr_version = {
        filename = "__base__/graphics/entity/construction-robot/hr-construction-robot-shadow.png",
        priority = "high",
        line_length = 16,
        width = 104,
        height = 49,
        frame_count = 1,
        shift = util.by_pixel(33.5, 18.75),
        direction_count = 16,
        scale = 0.5
      }
    } end
	b.working = function(levels,grade) return {
      filename = "__base__/graphics/entity/construction-robot/construction-robot-working.png",
      priority = "high",
      line_length = 2,
      width = 28,
      height = 36,
      frame_count = 2,
      shift = {0, -0.15625},
      direction_count = 16,
      animation_speed = 0.3,
      hr_version = {
        filename = "__base__/graphics/entity/construction-robot/hr-construction-robot-working.png",
        priority = "high",
        line_length = 2,
        width = 57,
        height = 74,
        frame_count = 2,
        shift = util.by_pixel(-0.25, -5),
        direction_count = 16,
        animation_speed = 0.3,
        scale = 0.5
      }
    } end
	b.shadow_working = function(levels,grade) return {
      stripes = util.multiplystripes(2,
      {
        {
          filename = "__base__/graphics/entity/construction-robot/construction-robot-shadow.png",
          width_in_frames = 16,
          height_in_frames = 1,
        }
      }),
      priority = "high",
      width = 50,
      height = 24,
      frame_count = 2,
      shift = {1.09375, 0.59375},
      direction_count = 16
    } end
	b.working_sound = function(levels,grade) return flying_robot_sounds() end
    b.cargo_centered = function(levels,grade) return {0.0, 0.2} end
    b.construction_vector = function(levels,grade) return {0.30, 0.22} end
	return setmetatable(b,BotGen)
end
function BotGen:setAllAnimation(n)
	if type(n)=="function" then
		self.energy_per_tick = n
	elseif type(n)=="number" then
		self.energy_per_tick = function(levels,grade) return n.."J" end
	elseif type(n)=="string" then
		self.energy_per_tick = function(levels,grade) return n end
	end
	return self
end
function BotGen:setTickEnergy(n)
	if type(n)=="function" then
		self.energy_per_tick = n
	elseif type(n)=="number" then
		self.energy_per_tick = function(levels,grade) return n.."J" end
	elseif type(n)=="string" then
		self.energy_per_tick = function(levels,grade) return n end
	end
	return self
end
function BotGen:setChargeLevels(mini,maxi)
	if type(mini)=="function" then
		self.min_to_charge = mini
	else
		self.min_to_charge = function(levels,grade) return mini end
	end
	if type(maxi)=="function" then
		self.max_to_charge = maxi
	else
		self.max_to_charge = function(levels,grade) return maxi end
	end
	return self
end
function BotGen:setPowerPenalty(n)
	if type(n)=="function" then
		self.speed_multiplier_when_out_of_energy = n
	else
		self.speed_multiplier_when_out_of_energy = function(levels,grade) return n end
	end
	return self
end
function BotGen:setPayload(n)
	if type(n)=="function" then
		self.max_payload_size = n
	else
		self.max_payload_size = function(levels,grade) return n end
	end
	return self
end
function BotGen:setTransfer(n)
	if type(n)=="function" then
		self.transfer_distance = n
	else
		self.transfer_distance = function(levels,grade) return n end
	end
	return self
end
function BotGen:setMaxEnergy(n)
	if type(n)=="function" then
		self.max_energy = n
	elseif type(n)=="number" then
		self.max_energy = function(levels,grade) return n.."MJ" end
	elseif type(n)=="string" then
		self.max_energy = function(levels,grade) return n end
	end
	return self
end


--[[
setTechUpgrade(value)
setTechCost(cost)
setTechIcon(mod,icon)
setTechPacks(cost)
setTechTime(t)
setTechPrereq(prereq)
function BuildGen:()

end
]]