for _, t in pairs({"recipe","item"}) do
	for _,d in pairs(data.raw[t]) do
		if d.icon_size == nil then
			d.icon_size=32
		end
	end
end